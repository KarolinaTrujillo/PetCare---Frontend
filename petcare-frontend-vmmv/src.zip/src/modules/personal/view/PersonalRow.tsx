import React from "react";
import { VeterinarioUI } from "../model/ui.model";

interface VeterinarioRowProps {
  veterinario: VeterinarioUI;
}

function Avatar({ initials }: { initials: string }) {
  return (
    <div
      style={{
        width: "42px",
        height: "42px",
        borderRadius: "50%",
        backgroundColor: "#E6F4F1",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: "13px",
        fontWeight: 700,
        color: "#2F8F7A",
        flexShrink: 0,
        border: "2px solid #D1EAE4",
      }}
    >
      {initials}
    </div>
  );
}

function EstadoBadge({ estado }: { estado: VeterinarioUI["estado"] }) {
  const isActive = estado === "Activo";
  return (
    <span
      style={{
        display: "inline-block",
        padding: "3px 14px",
        borderRadius: "20px",
        fontSize: "11px",
        fontWeight: 700,
        letterSpacing: "0.05em",
        textTransform: "uppercase",
        backgroundColor: isActive ? "#E6F4F1" : "#F3F4F6",
        color: isActive ? "#2F8F7A" : "#6B7280",
      }}
    >
      {estado}
    </span>
  );
}

function IconButton({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <button
      title={title}
      style={{
        width: "30px",
        height: "30px",
        borderRadius: "8px",
        border: "none",
        backgroundColor: "transparent",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
        color: "#6BAF9F",
      }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLButtonElement).style.backgroundColor = "#E6F4F1";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLButtonElement).style.backgroundColor = "transparent";
      }}
    >
      {children}
    </button>
  );
}

export default function VeterinarioRow({ veterinario }: VeterinarioRowProps) {
  return (
    <tr
      style={{ borderBottom: "1px solid #F3F4F6" }}
      onMouseEnter={(e) => {
        (e.currentTarget as HTMLTableRowElement).style.backgroundColor = "#FAFAFA";
      }}
      onMouseLeave={(e) => {
        (e.currentTarget as HTMLTableRowElement).style.backgroundColor = "transparent";
      }}
    >
      {/* Veterinario */}
      <td style={{ padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <Avatar initials={veterinario.avatarInitials} />
          <div>
            <p style={{ fontSize: "14px", fontWeight: 600, color: "#1F2937", marginBottom: "2px" }}>
              {veterinario.nombre}
            </p>
            <p style={{ fontSize: "12px", color: "#6B7280" }}>{veterinario.especialidad}</p>
          </div>
        </div>
      </td>

      {/* Contacto */}
      <td style={{ padding: "16px 20px" }}>
        <p style={{ fontSize: "14px", color: "#1F2937", marginBottom: "2px" }}>{veterinario.telefono}</p>
        <p style={{ fontSize: "12px", color: "#6B7280" }}>{veterinario.email}</p>
      </td>

      {/* Cédula / ID */}
      <td style={{ padding: "16px 20px" }}>
        <p style={{ fontSize: "14px", color: "#1F2937", fontWeight: 500 }}>{veterinario.cedula}</p>
      </td>

      {/* Estado */}
      <td style={{ padding: "16px 20px" }}>
        <EstadoBadge estado={veterinario.estado} />
      </td>

      {/* Acciones */}
      <td style={{ padding: "16px 20px" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "4px" }}>
          <IconButton title="Editar veterinario">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
              <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
          </IconButton>
          <IconButton title="Ver detalle">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
          </IconButton>
        </div>
      </td>
    </tr>
  );
}